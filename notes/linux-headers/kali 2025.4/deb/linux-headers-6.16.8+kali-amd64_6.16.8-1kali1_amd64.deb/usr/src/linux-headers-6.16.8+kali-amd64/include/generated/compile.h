#define UTS_MACHINE		"x86_64"
#define LINUX_COMPILE_BY	"devel"
#define LINUX_COMPILE_HOST	"kali.org"
#define LINUX_COMPILER		"x86_64-linux-gnu-gcc-14 (Debian 14.3.0-8) 14.3.0, GNU ld (GNU Binutils for Debian) 2.45"
